import Vista.Vistas_Generales.Interfaz_Inicial;

public class Main {
    public static void main(String[] args) {
        Interfaz_Inicial interfazInicial=new Interfaz_Inicial();
        interfazInicial.Inicializar_Interfaz_inicial();
    }
}
