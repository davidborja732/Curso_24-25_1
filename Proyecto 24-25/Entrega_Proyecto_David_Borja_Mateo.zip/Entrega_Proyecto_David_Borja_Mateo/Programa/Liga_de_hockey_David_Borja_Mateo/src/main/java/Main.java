import Vista.Interfaz_Inicial;

public class Main {
    public static void main(String[] args) {
        Interfaz_Inicial interfaz=new Interfaz_Inicial();
        interfaz.Inicializar_Interfaz_inicial();
    }
}
