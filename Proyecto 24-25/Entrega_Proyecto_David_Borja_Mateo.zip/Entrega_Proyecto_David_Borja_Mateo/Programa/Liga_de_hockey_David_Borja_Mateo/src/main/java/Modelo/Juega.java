package Modelo;

public class Juega {
    private int ID_partido;
    private int ID_equipo;
    private String ROL;

    public Juega(int ID_equipo, int ID_partido, String ROL) {
        this.ID_equipo = ID_equipo;
        this.ID_partido = ID_partido;
        this.ROL = ROL;
    }

    public int getID_equipo() {
        return ID_equipo;
    }

    public void setID_equipo(int ID_equipo) {
        this.ID_equipo = ID_equipo;
    }

    public String getROL() {
        return ROL;
    }

    public void setROL(String ROL) {
        this.ROL = ROL;
    }

    public int getID_partido() {
        return ID_partido;
    }

    public void setID_partido(int ID_partido) {
        this.ID_partido = ID_partido;
    }
}
