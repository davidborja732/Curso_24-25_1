altura = int(input("Introduce altura para el triángulo: "))
for i in range(1, altura + 1):
    print('*' * i)